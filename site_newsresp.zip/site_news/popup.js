// popup.js
document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("showMessage");

  button.addEventListener("click", function () {
    const message = "Olá, mundo!";
    alert(message);
  });
});
